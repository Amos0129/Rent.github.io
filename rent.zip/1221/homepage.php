<!DOCTYPE html>
	<html lang="en">
	<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>致理i租屋</title>
    <link rel="stylesheet" type="text/css" href="css/homepage.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    </head>
	<body>
    <?php
    //session_start();
    error_reporting(0);
    ?>
        <header class="main-header">
            <div class="container">
                <a href="" class="logo">
                    <img src="img/logo.png" alt="">
                </a>
            <nav class="main-nav">
                <a href="homepage.php">首頁</a>
                <a href="faq.php">諮詢中心</a>
                <a href="manage.php">租屋管理區</a>
                <?php               
                  if($_SESSION['mylogin'] && $_SESSION['account']){
                      echo "<a href='loginOut.php'>登出</a>";
                  }
                  else{
                      echo "<a href='login.php'>登入</a>";
                  }
                ?>
            </nav>
        </div>
        </header>

<div class="form">
    <form id="form" name="form" action="search.php" method='GET' class="form">
      <span>位置：</span>
      <input id="local-1" type="checkbox" value="板橋區" name="address[]">
      <label for="local-1">板橋區</label>
      <input id="local-2" type="checkbox" value="三重區" name="address[]">
      <label for="local-2">三重區</label>
      <input id="local-3" type="checkbox" value="新莊區" name="address[]">
      <label for="local-3">新莊區</label>
      <input id="local-4" type="checkbox" value="樹林區" name="address[]">
      <label for="local-4">樹林區</label>
      <input id="local-5" type="checkbox" value="土城區" name="address[]">
      <label for="local-5">土城區</label>
      <input id="local-6" type="checkbox" value="中和區" name="address[]">
      <label for="local-6">中和區</label>
      <input id="local-7" type="checkbox" value="萬華區" name="address[]">
      <label for="local-7">萬華區</label></br>

      <br>
        <div  class = "select" >
        <span> 類型： </span> 
          <select  name = "type" >
            <option  value = "" selected > 請選擇類型 </option >
            <option  value = "整層住家" > 整層住家 </option > 
            <option  value = "獨立套房" > 獨立套房 </option > 
            <option  value = "分租套房"  > 分租套房 </option > 
            <option value = "雅房" > 雅房 </option > 
          </select> 
        </div >
        <br>
        <br>
        <div  class = "select" >
        <span> 房數： </span>  
          <select  name = "number" >
            <option  value = "" selected > 請選擇房數 </option >
            <option  value = "一房" > 一房 </option > 
            <option  value = "二房" > 二房 </option > 
            <option  value = "三房"  > 三房 </option > 
            <option value = "四房" > 四房 </option > 
          </select > 
        </div >
        <br>
        <br>       
        <div  class = "select" >
        <span> 租金： </span > 
          <select  name = "money" >
            <option  value = "" selected > 請選擇租金 </option >
            <option  value = "0-5000元" > 0-5000元 </option > 
            <option  value = "5000-10000元" > 5000-10000元 </option > 
            <option  value = "10000-20000元"  > 10000-20000元 </option > 
            <option value = "20000元以上" > 20000元以上 </option > 
          </select > 
        </div ></br>

        <span>坪數：</span>
        <input id="10 ping or less" type="checkbox" value="10坪以下" name="square[]">
        <label for="10 ping or less">10坪以下</label>
        <input id="10-20 ping" type="checkbox" value="10-20坪" name="square[]">
        <label for="10-20 ping">10-20坪</label>
        <input id="20-30 ping" type="checkbox" value="20-30坪" name="square[]">
        <label for="20-30 ping">20-30坪</label></br>

        <span>樓層：</span>
        <input id="1 story" type="checkbox" value="1層" name="layers[]">
        <label for="1 story">1層</label>
        <input id="2-6 story" type="checkbox" value="2-6層" name="layers[]">
        <label for="2-6 story">2-6層</label>
        <input id="6-12 story" type="checkbox" value="6-12層" name="layers[]">
        <label for="6-12 story">6-12層</label></br>

        <span>設備：</span>
        <input id="air conditioner" type="checkbox" value="冷氣" name="equipment[]">
        <label for="air conditioner">有冷氣</label>
        <input id="washing machine" type="checkbox" value="洗衣機" name="equipment[]">
        <label for="washing machine">有洗衣機</label>
        <input id="refrigerator" type="checkbox" value="冰箱" name="equipment[]">
        <label for="refrigerator">有冰箱</label>
        <input id="water heater" type="checkbox" value="熱水器" name="equipment[]">
        <label for="water heater">有熱水器</label>
        <input id="natural gas" type="checkbox" value="天然瓦斯" name="equipment[]">
        <label for="natural gas">有天然瓦斯</label>
        <input id="network" type="checkbox" value="網路" name="equipment[]">
        <label for="network">有網路</label>
        <input id="Exclude roof caps" type="checkbox" value="排除頂樓加蓋" name="equipment[]">
        <label for="Exclude roof caps">排除頂樓加蓋</label></br>
 
      <div class="btn">
        <input type="submit" value="  搜尋🔍 " name="submit">
      </div>
  </form>
  </div>
  <div class="filter">
        <div class="tb" align="center">    
            <?php
                
            require_once('connectDB.php');
                $counter = 0;
            
			?>

<div class="wrap">
      <p id="info"></p>
      <?php
        $query = "SELECT * FROM (SELECT * FROM `form` WHERE `照片` != '') AS NotNull ORDER BY RAND() LIMIT 4";

        $query_run = mysqli_query($link,$query);
        $str = "";
        if(mysqli_num_rows($query_run) > 0)
        {
          foreach($query_run as $row)
          {
            if($row["審核"]=="通過" && $row["是否出租"]=="否")
            {
              $path = $row["照片"];
              $path = explode(',', $path);
              echo "<div class=\"items\">";?>
              <div id="carouselExampleControls<?php echo $counter ?>" class="carousel slide">
              <div class="carousel-inner">
                <div class="carousel-item active">
                <?php
                  echo "<img src=\"img\\$path[0]\" alt=\"無\" height=250px class='d-block w-100'>";
                ?>
                </div>
                <div class="carousel-item">
                <?php
                  echo "<img src=\"img\\$path[1]\" alt=\"無\" height=250px class='d-block w-100'>";
                ?>
                </div>
                <div class="carousel-item">
                <?php
                  echo "<img src=\"img\\$path[2]\" alt=\"無\" height=250px class='d-block w-100'>";
                ?>
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls<?php echo $counter ?>" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls<?php echo $counter ?>" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
            <?php
              $num = $counter + 1;
              echo "<h3>房型$num</h3>";
              echo "<p>地址:$row[地址]</p>";
              echo "<p>租金:$row[租金]元</p>";
              echo "<p>類型:$row[類型]</p>";
              echo "<p>姓名:$row[聯絡人姓名]</p>";
              echo "<p>聯絡電話:$row[聯絡人電話]</p>";
              echo "</div>";
              $counter++;
            }
          }
        }   
      ?>
      </div>
        </div>

        <footer>
            <div class="footer">
                <p>
                    220305 新北市板橋區文化路1段313號<br>
                    No.313, Sec. 1, Wenhua Rd., Banqiao Dist., New Taipei City 220305, Taiwan (R.O.C.)<br>
                    TEL：(02)2257-6167 │ (02)2257-6168 │ FAX：(02)2258-3710
                </p>
            </div>
        </footer>
    </body>
</html>
