<?php
    require_once('connectDB.php');

    if(isset($_GET["submit"]))
    {
        if(!empty($_GET['equipment']) && !empty($_GET['safety']))
        {
            $equipment = array();
            $safety = array();
            $date = date('Y/m/d');
            
            $address=$_GET["address"];
            $type=$_GET["type"];
            $number=$_GET["number"];
            $money=$_GET["money"];
            $square=$_GET["square"];
            $layers=$_GET["layers"];
            $equipment=$_GET["equipment"];
            $img=$_GET["img"];
            $text=$_GET["text"];
            $safety=$_GET["safety"];
            $rent=$_GET["rent"];
            $personName=$_GET["personName"];
            $tel=$_GET["tel"];

            $img = implode(',', $img);
            $equipment = implode(',', $equipment);
            $safety = implode(',', $safety);
        }

        $sql="INSERT INTO `form` (`地址`, `類型`, `房數`, `租金`,`坪數`, `樓層`, `設備`, `上傳日期`, `照片`, `備註`, `安全項目`, `是否出租`, `聯絡人姓名`, `聯絡人電話`) VALUES ('".$address."', '".$type."', '".$number."', '".$money."', '".$square."', '".$layers."', '".$equipment."', '".$date."', '".$img."', '".$text."', '".$safety."','".$rent."','".$personName."','".$tel."')";

        $result = mysqli_query($link, $sql);

        if($result)
        {           
            echo "<script language=javascript>alert('新增成功！')</script>";
            echo "<script language=javascript>location.href='upload.php'</script>"; 
        }
        else{
            echo "Failed!<br>";
            echo mysqli_errno($link);
        }        
        mysqli_close($link);
    }
    else{
        echo "操作錯誤!";
        header('Location:homepage.php');
    }
?>