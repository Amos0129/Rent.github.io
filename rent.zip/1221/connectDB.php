<?php
    $host="localhost";
    $account="root";
    $password="";
    $database="topic";

    $link = @mysqli_connect($host,$account,$password,$database); //設定資料庫連結，包括連結位置、帳號、密碼、資料庫名字

    /*if(!$link) //確定資料庫連結是否成功
    {
	    echo "資料連結失敗";
    }
    else
	    echo"資料連結成功";*/
?>