<?php
include('connectDB.php');
session_start(); //啟用Session功能

$account = $_POST["account"];
$password = $_POST["password"];

$sql = "select * from administrator where account = '$account' and password = '$password'";

$result = mysqli_query($link, $sql);
$rows=mysqli_num_rows($result);
$re = mysqli_fetch_row($result);

if($rows)
{
    echo "登入成功,寫入session與cookie<br>";
    $_SESSION['account'] = $account;
	$_SESSION['mylogin'] = true;//將此值記錄於Session變數
	echo "登入狀態:".$_SESSION['mylogin']."<Br>";//測試讀出Sessio
    echo "<script language=javascript>alert('登入成功！')</script>";
    header("refresh:0;url=manage.php");
    //exit;
}
else
{
    $_SESSION['mylogin'] = NULL;
    //echo "登入狀態:".$_SESSION['mylogin']."<Br>";
    echo "<script language=javascript>alert('帳號密碼有誤！')</script>";
    header("refresh:0;url=login.php");
}




mysqli_close($link);
?>