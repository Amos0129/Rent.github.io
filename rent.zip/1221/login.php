<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>致理i租屋</title>
    <link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
<?php
          session_start();
          error_reporting(0);
        ?>
    <header class="main-header">
        <div class="container">
            <a href="" class="logo">
                <img src="img/logo.png" alt="">
            </a>
        <nav class="main-nav">
            <a href="homepage.php">首頁</a>
            <a href="faq.php">諮詢中心</a>
            <a href="manage.php">租屋管理區</a>
            <?php               
                  if($_SESSION['mylogin'] && $_SESSION['account']){
                    echo "<a href='loginOut.php'>登出</a>";
                  }
                  else{
                    echo "<a href='login.php'>登入</a>";
                  }
                ?>
        </nav>
        </div>
    </header>

    <div class="mid">
    <div class="login">
        <form action="login-config.php" method="post">
            <h2>致理i租屋</h2>
            <div class="group">
                <label for="">帳號</label>
                <input type="text" name="account" placeholder="輸入帳號" maxlength="8" autofocus>
            </div>
            <div class="group">
                <label for="">密碼</label>
                <input type="password" name="password" placeholder="輸入密碼">
            </div>
            <div class="btn-group">
                <button class="btn">登入</button>
                <button class="btn">取消</button>
            </div>
        </form>
    </div> 
    </div>
</body>
</html>