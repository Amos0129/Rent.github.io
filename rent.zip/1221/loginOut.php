<?php
    session_start();
    session_destroy();
    //導到login.php 
    header("Location:login.php");
?>