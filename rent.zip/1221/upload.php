<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>房屋上傳區</title>
    <link rel="stylesheet" type="text/css" href="css/upload.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" >
</head>
<body>
<?php
          session_start();
          if($_SESSION['mylogin']){
              
        }else{
            echo "<script language=javascript>alert('請登入')</script>";
            header("refresh:0;url=login.php");
        }
        ?>
    <header class="main-header">
        <div class="container">
            <a href="" class="logo">
                <img src="img/logo.png" alt="">
            </a>
            <nav class="main-nav">
                <a href="homepage.php">首頁</a>
                <a href="faq.php">諮詢中心</a>
                <a href="manage.php">租屋管理區</a>
                <?php               
                  if($_SESSION['mylogin'] && $_SESSION['account']){
                    echo "<a href='loginOut.php'>登出</a>";
                  }
                  else{
                    echo "<a href='login.php'>登入</a>";
                  }
                ?>
            </nav>
        </div>
    </header>

    <div class="mid">
        <div class="main">     
        <form action="formUpload.php" method="get">
            <h1>上傳房屋資訊</h1>
            <div class="input-data">
                <span>地址:</span>
                <input type="text" name="address" placeholder="輸入地址" required>
            </div>
			<br>
            <div class="select">
                <span>類型:</span>
                <select id="mnya-select" name="type" required>
                    <option>請選擇類型</option>
                    <option>整層住家</option>
                    <option>獨立套房</option>
                    <option>分租套房</option>
                    <option>雅房</option>
                </select>            
            </div>
			<br><br>
            <div class="input-dataN">
                <span>房數:</span>
                <input type="number" name="number" placeholder="輸入房數" required>
            </div>
			<br>
            <div class="input-dataN">
                <span>租金:</span>
                <input type="number" name="money" placeholder="輸入租金" required>
            </div>
			<br>
            <div class="input-dataN">
                <span>坪數:</span>
                <input type="number" name="square" placeholder="輸入坪數" required>
            </div>
            <br>
            <div class="input-dataN">
                <span>樓層:</span>
                <input type="number" name="layers" placeholder="輸入樓層" required>
            </div>
			<br>
            
            <div class="checkbox">
                <span>設備:</span>
                <div>
                <input type="checkbox" id="air conditioner" name="equipment[]" value="冷氣" class="regular-checkbox"/>
                <label for="air conditioner">有冷氣</label>&nbsp;&nbsp;
                
                <input type="checkbox" id="washing machine" name="equipment[]" value="洗衣機" class="regular-checkbox"/>
                <label for="washing machine">有洗衣機</label>&nbsp;&nbsp;
                    
                <input type="checkbox" id="refrigerator" name="equipment[]" value="冰箱" class="regular-checkbox"/>               
                <label for="refrigerator">有冰箱</label>&nbsp;&nbsp;
                    
                <input type="checkbox" id="water heater" name="equipment[]" value="熱水器" class="regular-checkbox"/>              
                <label for="water heater">有熱水器</label>&nbsp;&nbsp;
                    
                <input type="checkbox" id="natural gas" name="equipment[]" value="天然瓦斯" class="regular-checkbox"/>
                <label for="natural gas">有天然瓦斯</label>&nbsp;&nbsp;
                <br>
                <input type="checkbox" id="network" name="equipment[]" value="網路" class="regular-checkbox"/>
                <label for="network">有網路</label>&nbsp;&nbsp;
                    
                <input type="checkbox" id="Exclude roof caps" name="equipment[]" value="排除頂樓加蓋" class="regular-checkbox"/>
                <label for="Exclude roof caps">排除頂樓加蓋</label>&nbsp;&nbsp;
                </div>
            </div>
			<br>
            <div class="img" id="picInput">
                <span>照片上傳:</span>
                <input type="file" name="img[]" multiple="multiple">
            </div>
            <br>
            <div class="personName" id="personName">
                <span>聯絡人姓名:</span>
                <input type="text" name="personName" placeholder="輸入姓名" required>
            </div>
            <br>
            <div class="tel" id="tel">
                <span>聯絡人電話:</span>
                <input type="tel" name="tel" placeholder="輸入電話" required>
            </div>
			<br>
            <div class="textarea">
                <span>須知備註:</span><br><br>
                <textarea name="text" id="" cols="85" rows="10"></textarea>
            </div>
			<br>
            <div class="checkbox">
                <span>安全項目:</span>

                <input type="checkbox" id="air conditioner" name="safety[]" value="消防設施" class="regular-checkbox"/>
                <label for="air conditioner">消防設施</label>&nbsp;&nbsp;
                
                <input type="checkbox" id="washing machine" name="safety[]" value="熱水器排氣功能" class="regular-checkbox"/>
                <label for="washing machine">熱水器排氣功能</label>&nbsp;&nbsp;
                    
                <input type="checkbox" id="refrigerator" name="safety[]" value="門禁" class="regular-checkbox"/>               
                <label for="refrigerator">門禁</label>&nbsp;&nbsp;              
            </div>
			<br>
            <div class="radio">
                <span>是否出租:</span>
                <input type="radio" id="yes" name="rent" value="是">
                <label for="yes">是</label>

                <input type="radio" id="no" name="rent" value="否">
                <label for="no">否</label><br>
            </div>
            <br>
            <div class="submit">
                <input type="submit" name="submit">
            </div>  
        </form>
        </div>
    </div>
</body>
</html>