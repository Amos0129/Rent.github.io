<?php
    require_once('connectDB.php');

    if(isset($_GET["submit"]))
    {
        $date = date('Y/m/d');
        $name = $_GET["username"];
        $email=$_GET["useremail"];
        $question = $_GET["feedback"];

        $sql="INSERT INTO `q&a` (`留言時間`, `姓名`, `e-mail`, `意見內容`) VALUES ('".$date."', '".$name."', '".$email."', '".$question."')";


        $result = mysqli_query($link, $sql);

        if($result)
        {           
            echo "<script language=javascript>alert('送出成功！')</script>";
            echo "<script language=javascript>location.href='faq.php'</script>"; 
        }
        else{
            echo "Failed!<br>";
            echo mysqli_errno($link);
        }        
        mysqli_close($link);
    }
    else{
        echo "操作錯誤!";
        header('Location:homepage.php');
    }
?>