<!DOCTYPE html>
	<html lang="en">
	<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>致理i租屋</title>
    <link rel="stylesheet" type="text/css" href="css/search.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    
    </head>
	<body>
    <?php

    function SQL_printer($type, $array){
        $SQL_append = "";

        if(!$array){
            return $SQL_append;
        }

        $SQL_counter = 0;

        foreach($array as $item){
            if($SQL_counter != 0)
                $SQL_append .= " OR";

            if($type == "坪數" || $type == "樓層"){
                $SQL_append .= "(`$type` ";
                switch($item){
                    case '10坪以下':
                        $SQL_append .= 'BETWEEN 0 AND 10)';
                        break;

                    case '10-20坪':
                        $SQL_append .= 'BETWEEN 10 AND 20)';
                        break;

                    case '20-30坪':
                        $SQL_append .= 'BETWEEN 20 AND 30)';
                        break;     
                        
                    case '1層':
                        $SQL_append .= 'BETWEEN 1 AND 1)';
                        break;

                    case '2-6層':
                        $SQL_append .= 'BETWEEN 2 AND 6)';
                        break;

                    case '6-12層':
                        $SQL_append .= 'BETWEEN 6 AND 12)';
                        break;          
                }
            }
            else
                $SQL_append .= " `".$type."` like ('%".$item."%')";

            $SQL_counter ++;
        }
        return $SQL_append;
    }

    ?>

    <?php
        session_start();
        error_reporting(0);
    ?>
    <header class="main-header">
        <div class="container">
            <a href="" class="logo">
                <img src="img/logo.png" alt="">
            </a>
        <nav class="main-nav">
            <a href="homepage.php">首頁</a>
            <a href="faq.php">諮詢中心</a>
            <a href="manage.php">租屋管理區</a>
            <?php               
                if($_SESSION['mylogin'] && $_SESSION['account'])
                {
                    echo "<a href='loginOut.php'>登出</a>";
                }
                else{
                    echo "<a href='login.php'>登入</a>";
                  }
            ?>
        </nav>
        </div>
    </header>

    <?php

        require_once('connectDB.php');

        if(isset($_GET["submit"]))
        {
            $address = array();
            $square = array();
            $layers = array();
            $equipment = array();
            $notice = array();
                    
            $address=$_GET["address"];
            $type=$_GET["type"];
            $number=$_GET["number"];
            $money=$_GET["money"];
            $square = $_GET["square"];
            $layers=$_GET["layers"];      
            $equipment=$_GET["equipment"];

            //$address = implode(',', $address);
            //$square = implode(',', $square);
            //$layers = implode(',', $layers);
            //$equipment = implode(',', $equipment);


            /*echo $address."<br>";
            echo $type."<br>";
            echo $number."<br>";
            echo $money."<br>";
            echo $square."<br>";
            echo $layers."<br>";
            echo $equipment."<br>";*/


            //$sql="INSERT INTO `form` (`地址`, `類型`, `房數`, `租金`, `樓層`, `設備`, `上傳日期`, `照片`, `備註`, `安全項目`, `是否出租`) VALUES ('".$address."', '".$type."', '".$number."', '".$money."', '".$layers."', '".$equipment."', '".$date."', '".$img."', '".$text."', '".$safety."','".$rent."')";
            //$result = mysqli_query($link, $sql);
        }
        else{
            echo "操作錯誤!";
            header('Location:homepage.php');
        }
    ?>

<div class="filter">
        <div class="tb" align="center">    
        <table  border="2px" class="table table-Warning table-striped">
            <tr id="tab">
                <th>照片</th>
                <th>地址</th>
                <th>類型</th>
                <th>房數</th>
                <th>租金</th>
                <th>坪數</th>
                <th>樓層</th>
                <th>聯絡人</th>
                <th>聯絡人電話</th>
                <th>設備</th>
                <th>上傳日期</th>
                <th>備註</th>
                <th>安全項目</th>
                <th>是否出租</th>
            </tr>
            <?php
                if($money){
                    switch($money){
                        case '0-5000元':
                            $money = 'BETWEEN 0 AND 5000';
                            break;

                        case '5000-10000元':
                            $money = 'BETWEEN 5000 AND 10000';
                            break;

                        case '10000-20000元':
                            $money = 'BETWEEN 5000 AND 10000';
                            break;
                            
                        case '20000元以上':
                            $money = 'BETWEEN 5000 AND 10000';
                            break;
                    }
                }

                if($number){
                    switch($number){
                        case '一房':
                            $number = '1';
                            break;

                        case '二房':
                            $number = '2';
                            break;

                        case '三房':
                            $number = '3';
                            break;
                            
                        case '四房':
                            $number = '4';
                            break;
                    }
                }

                if($square){
                    switch($square){
                        case '10坪以下':
                            $square = 'BETWEEN 0 AND 10';
                            break;

                        case '10-20坪':
                            $square = 'BETWEEN 10 AND 20';
                            break;

                        case '20-30坪':
                            $square = 'BETWEEN 20 AND 30';
                            break;                           
                    }
                }

                if($layers){
                    switch($layers){
                        case '1層':
                            $layers = 'BETWEEN 1 AND 1';
                            break;

                        case '2-6層':
                            $layers = 'BETWEEN 2 AND 6';
                            break;

                        case '6-12層':
                            $layers = 'BETWEEN 6 AND 12';
                            break;                            
                    }
                }

                $SQL_append = "";

                $typeArray=[
                    "地址"=>$address,
                    "坪數"=>$square,
                    "樓層"=>$layers,
                    "設備"=>$equipment
            ];
                
            foreach($typeArray as $key => $value)
            {

                if($value)
                    $SQL_append .= " AND";

                if(count($value) > 1)
                    $SQL_append .= " (";

                $SQL_append .= SQL_printer($key, $value);

                if(count($value) > 1)
                    $SQL_append .= ")";
            }

            $query = "SELECT * FROM form WHERE `類型` = '$type' and `房數` = '$number' and `租金` $money".$SQL_append;

            $query_run = mysqli_query($link,$query);
            $str = "";
			if(mysqli_num_rows($query_run) > 0)
			{
                $counter = 0;
				foreach($query_run as $row)
				{
                    if($row["審核"]=="通過" && $row["是否出租"]=="否")
                    {
                        $path = $row["照片"];
                        $path = explode(',', $path);

                        error_reporting(0);

			?>
					<tr>
                        <td width='400px'>
                            <div id="carouselExampleControls<?php echo $counter ?>" class="carousel slide">
                                <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <?php
                                        echo "<img src=\"img\\$path[0]\" alt=\"無\" height=250px class='d-block w-100'>";
                                    ?>
                                </div>
                                <div class="carousel-item">
                                    <?php
                                        echo "<img src=\"img\\$path[1]\" alt=\"無\" height=250px class='d-block w-100'>";
                                    ?>
                                </div>
                                <div class="carousel-item">
                                    <?php
                                        echo "<img src=\"img\\$path[2]\" alt=\"無\" height=250px class='d-block w-100'>";
                                    ?>
                                </div>
                                </div>
                                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls<?php echo $counter ?>" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls<?php echo $counter ?>" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>

                        </td>
						<td><?php echo $row["地址"];        ?></td> 
						<td><?php echo $row["類型"];        ?></td> 
						<td><?php echo $row["房數"]."房";   ?></td>
                        <td><?php echo $row["租金"]."元";   ?></td>
                        <td><?php echo $row["坪數"]."坪";   ?></td> 
						<td><?php echo $row["樓層"]."樓";   ?></td>
                        <td><?php echo $row["聯絡人姓名"];  ?></td>
                        <td><?php echo $row["聯絡人電話"];  ?></td>
						<td><?php echo $row["設備"];        ?></td>
                        <td><?php echo $row["上傳日期"];    ?></td>
                        <td><?php echo $row["備註"];        ?></td>
                        <td><?php echo $row["安全項目"];    ?></td>
                        <td><?php echo $row["是否出租"];    ?></td><br>
					</tr>    
			<?php
            $counter++;
                        }   
				    }
				}       
			?>
        </table>
        </div>
    </div>
    </body>
</html>