<?php
    require_once('connectDB.php');

    $audit = array(
        "true" => "通過",
        "false" => "未通過"
    );
    
    $number = $_POST["Number"];
    $status = $_POST["Status"];

    $sql="UPDATE `form` SET `審核`= '$audit[$status]' WHERE `form`.`編號` = '$number'";
    $result = mysqli_query($link, $sql);

    mysqli_close($link);
?>