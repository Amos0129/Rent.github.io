<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>FAQs</title>
    <link rel="stylesheet"  href="css/faq.css"/>
</head>
<body>
	<?php
		require_once('connectDB.php');
        session_start();
        error_reporting(0);
    ?>
    <header class="main-header">
        <div class="container">
            <a href="" class="logo">
                <img src="img/logo.png" alt="">
            </a>
        <nav class="main-nav">
            <a href="homepage.php">首頁</a>
            <a href="faq.php">諮詢中心</a>
            <a href="manage.php">租屋管理區</a>
            <?php
                if($_SESSION['mylogin']){
                    echo "<a href='loginOut.php'>登出</a>";
                }
                 else{
                    echo "<a href='login.php'>登入</a>";
                 }   
            ?>
        </nav>
        </div>
    </header>
		<div class="mid">
		
		<section><div class="rh-label border-indigo">
            <span class="rh-label-title bg-indigo">租屋FAQ</span>
        </div>
		
		<div class="wrap">
		
		搜尋：<input type="search" id="myInput" class="light-table-filter" data-table="order-table" placeholder="請輸入關鍵字" onkeydown="show()">
		</div>
		<table class="order-table" id="myTable" style="display: none" >
		  <thead>
			
		  </thead>
		  <tbody>
			<tr>
			  <td>Q1.租屋一定要簽約嗎?</td>
			  <td>雖然在契約中有所謂的口頭契約，但基於避免發生不必要之困擾，最好是簽約並且房東與房客各持一份為佳。</td>
			</tr>
			<tr>
			  <td>Q2.當我與同學合租房子，但其中一位突然先離開退租時，我們該怎麼辦?</td>
			  <td>和同學一起租屋，為避免有同學因事必須先行退租，
				而影響其他人的權益時，
				在簽約時，每位同學都必須各持一份自己的租約，
				才不會在退租時影響到其他同學的權益。</td>
			</tr>
			<tr>
			  <td>Q3.租屋期間要是東西壞了怎麼辦?</td>
			  <td>租屋期間的修繕工作，主要由契約上所寫為主，一般由於房東為該建物所有人，
				公共器材之保養與修繕係由房東負責，而房客所居住的空間如有物品的破損，修繕責任以契約上所寫為主。</td>
			</tr>
			<tr>
			  <td>Q4.如果我和房東間有問題，我該如何自保?</td>
			  <td>本校的住宿中心，有提供學生申訴的管道，只要在住宿中心的正常上班時間，
				向中心申訴，本中心將會盡力為處理，以保障學生在外的租屋安全。</td>
			</tr>
			<tr>
			  <td>Q5.簽約時，房東要求留存我們的身分證影本，我可以拒絕嗎?留下來會有危險嗎?</td>
			  <td>房東會要求留存身分證影本，應是擔心在租賃期間發生任何狀況，
				會有找不到房客又無任何證明方式的困擾，同理而言，
				不論是房東對房客或是房客對房東應也是可以做相同的要求。</td>
			</tr>
			<tr>
			  <td>Q6.押金是什麼?可以拒交嗎?</td>
			  <td>押金在法律上的名稱為「押租金」，是為擔保房客的租金給付，以及作為日後賠償租約期間房客所造成的損害
				，另外押金必須在租約到期後，房客與房東雙方無任何利害關係，例如：該月水電費已全額付清且無賠償及續約問題時
				，要將押金全額退還房客。</td>
			</tr>
			<tr>
			  <td>Q7.訂金是什麼?</td>
			  <td>所謂訂金是契約履行前的一種承諾，民法第248條規定：「訂約當事人之一方，
				由他人受有訂金時，推定其契約成立。」所以當交付訂金後，就代表已經和房東有了租賃契約的成立了。</td>
			</tr>
			<tr>
			  <td>Q8.押金是什麼?可以拒交嗎?</td>
			  <td>押金在法律上的名稱為「押租金」，是為擔保房客的租金給付，以及作為日後賠償租約期間房客所造成的損害
				，另外押金必須在租約到期後，房客與房東雙方無任何利害關係，
				例如：該月水電費已全額付清且無賠償及續約問題時，要將押金全額退還房客。</td>
			</tr>
			<tr>
			  <td>Q5.簽約時，房東要求留存我們的身分證影本，我可以拒絕嗎?留下來會有危險嗎?</td>
			  <td>房東會要求留存身分證影本，應是擔心在租賃期間發生任何狀況，
				會有找不到房客又無任何證明方式的困擾，同理而言，
				不論是房東對房客或是房客對房東應也是可以做相同的要求。</td>
			</tr>
			
			
			
		  </tbody>
		</table>

 <script src="./test.js"></script>
		
		
		<br>
		<div class="faq">
            <div class="question">
            <h3>Q1.租屋一定要簽約嗎? </h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
                雖然在契約中有所謂的口頭契約，但基於避免發生不必要之困擾，最好是簽約並且房東與房客各持一份為佳。
            </p>
            </div>
        </div>
		
        <div class="faq">
            <div class="question">
            <h3>Q2.當我與同學合租房子，但其中一位突然先離開退租時，我們該怎麼辦?</h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
                和同學一起租屋，為避免有同學因事必須先行退租，
				而影響其他人的權益時，
				在簽約時，每位同學都必須各持一份自己的租約，
				才不會在退租時影響到其他同學的權益。
            </p>
            </div>
        </div>
		
		<div class="faq">
            <div class="question">
            <h3>Q3.租屋期間要是東西壞了怎麼辦? </h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
                租屋期間的修繕工作，主要由契約上所寫為主，一般由於房東為該建物所有人，
				公共器材之保養與修繕係由房東負責，而房客所居住的空間如有物品的破損，修繕責任以契約上所寫為主。
            </p>
            </div>
        </div>
		  <div class="faq">
            <div class="question">
            <h3>Q4.如果我和房東間有問題，我該如何自保? </h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
				本校的住宿中心，有提供學生申訴的管道，只要在住宿中心的正常上班時間，
				向中心申訴，本中心將會盡力為處理，以保障學生在外的租屋安全。
            </p>
            </div>
        </div>
			<div class="faq">
            <div class="question">
            <h3>Q5.簽約時，房東要求留存我們的身分證影本，我可以拒絕嗎?留下來會有危險嗎? </h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
				房東會要求留存身分證影本，應是擔心在租賃期間發生任何狀況，
				會有找不到房客又無任何證明方式的困擾，同理而言，
				不論是房東對房客或是房客對房東應也是可以做相同的要求。
            </p>
            </div>
        </div>
		
		
		 <div class="faq">
            <div class="question">
            <h3>Q6.押金是什麼?可以拒交嗎? </h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
				押金在法律上的名稱為「押租金」，是為擔保房客的租金給付，以及作為日後賠償租約期間房客所造成的損害
				，另外押金必須在租約到期後，房客與房東雙方無任何利害關係，例如：該月水電費已全額付清且無賠償及續約問題時
				，要將押金全額退還房客。
            </p>
            </div>
        </div>
		
		
		
		 <div class="faq">
            <div class="question">
            <h3>Q7.訂金是什麼? </h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
				所謂訂金是契約履行前的一種承諾，民法第248條規定：「訂約當事人之一方，
				由他人受有訂金時，推定其契約成立。」所以當交付訂金後，就代表已經和房東有了租賃契約的成立了。
            </p>
            </div>
        </div>
		
		<div class="faq">
            <div class="question">
            <h3>Q8.押金是什麼?可以拒交嗎?</h3>
            <svg width="15" height="10" viewBox="0 0 42 25">
                <path d="M3 3L21 21L39 3" stroke="white" stoke-width="7" stroke-linecap="round"/>
            </svg>
        </div>
        <div class="answer">
            <p>
				押金在法律上的名稱為「押租金」，是為擔保房客的租金給付，以及作為日後賠償租約期間房客所造成的損害
				，另外押金必須在租約到期後，房客與房東雙方無任何利害關係，
				例如：該月水電費已全額付清且無賠償及續約問題時，要將押金全額退還房客。
            </p>
            </div>
        </div>
	<br>
	<br>
	<br>
	<br>
	<div class="_args" data-waID="${pi.uPro.currentApp.waID}" data-appCode="${pi.appCode}"></div>
	<div class="rh-label border-indigo">
            <span class="rh-label-title bg-indigo">留言板</span>
        </div>
    <br>
	<h3>想說什麼，勇敢說！</h3>
	<h3>寫下你的資料與意見，我們將再與您聯絡。</h3>

	<br>
	<!-- 輸入框 先宣告submit不回傳 再定義各個欄位form內容 -->
	<form action="QA_submit.php" method="get">
	<label for="textfield">姓名：</label>
	<INPUT TYPE="text" id="username" name="username" value="" placeholder="請填入姓名" class="BG-Copy" size="30" />
	<label for="textfield">email：</label>
	<INPUT TYPE="text" id="useremail" name="useremail" value="" placeholder="請填入e-mail" class="BG-Copy" size="30" />
	<br>
	<p align="left"><label for="textfield">留言或提問：</label></p>
	<br>
	<TEXTAREA NAME="feedback" id="feedback" ROWS="8" COLS="85" placeholder="想詢問什麼都可以" class="BG-Copy"
	></TEXTAREA>
	<br>
	<!-- 定義送出鍵的動作，使用JavaScript的function-->
	<INPUT TYPE="submit" VALUE="送出" class="Base" name="submit"  onclick="processFormData(username,useremail)">
	</form>
	<!-- 分隔線hr -->
	<hr>
	<br>
	<br>
	<br>
	<br>
	<?php
		$query = "SELECT `留言時間`, `姓名`,`e-mail`,`意見內容` FROM `q&a`";
		$query_run = mysqli_query($link,$query);
	?>
	<CAPTION>
	<div class="rh-label border-indigo">
            <span class="rh-label-title bg-indigo">我的歷史紀錄</span>
        </div>
	</CAPTION>
	<br>
	<br>
	<!-- 表格定義 設定置中 -->
	<table width="100%" align="center" id='Feedback_table'>
	<tr>
		<th width="25%">留言時間</th>
		<th width="15%">姓名</th>
		<th width="20%">email</th>
		<th width="30%">意見內容</th>
	</tr>

	<?php
		if(mysqli_num_rows($query_run) > 0)
		{
			foreach($query_run as $row)
			{
	?>
			<tr class="col">
                <td><?php echo $row["留言時間"];    ?></td>
				<td><?php echo $row["姓名"];        ?></td> 
				<td><?php echo $row["e-mail"];      ?></td> 
				<td><?php echo $row["意見內容"];    ?></td>
			</tr>
	<?php
			}
		}     
	?>
	</table>		
	</section>
	</div>

    <script src="./faq.js"></script>
    <footer>
        <div class="footer">
            <p align="left"> 
                220305 新北市板橋區文化路1段313號<br>
                No.313, Sec. 1, Wenhua Rd., Banqiao Dist., New Taipei City 220305, Taiwan (R.O.C.)<br>
                TEL：(02)2257-6167 │ (02)2257-6168 │ FAX：(02)2258-3710
            </p>
        </div>
    </footer>
	</body>
</html>
