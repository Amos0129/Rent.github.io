const faqs = document.querySelectorAll(".faq");

faqs.forEach((faq) =>{
    faq.addEventListener("click", () =>{
        faq.classList.toggle("active");

    });
});

faqs.forEach(function(item){ //選擇每個QA方格

    if(item !== faq){ //只要不是被選擇的article

        item.classList.remove("p"); //就將"show-text"的Class移除

    };
});

faqs.forEach((faq) =>{
    faq.addEventListener("click", () =>{
        faq.classList.toggle("active");

    });
});

faqs.forEach(function(item){ //選擇每個QA方格

    if(item !== faq){ //只要不是被選擇的article

        item.classList.remove("p"); //就將"show-text"的Class移除

    };
});

var name = document.getElementById("username");
var email = document.getElementById("useremail");
var feedbackElement = document.getElementById("feedback");

function processFormData(name,email) {
    var names = name.value;
    var emails = email.value;
    alert("謝謝" + names + "的回饋，我們將再用email:" + emails + "與您聯繫!");
}
function addMsg() {
// 獲取table標籤元素
let table = document.getElementById("Feedback_table");
// 建立新行
let newRow = table.insertRow();
// 建立三個新單元格 向表格中插入元素
newRow.insertCell().innerHTML = new Date().toLocaleString();
newRow.insertCell().innerHTML = nameElement.value;
newRow.insertCell().innerHTML = emailElement.value;
newRow.insertCell().innerHTML = feedbackElement.value;
newRow.insertCell().innerHTML = '<input type="button" value="Delete" onclick="delRow(this)"></input>'
nameElement.value = '';
emailElement.value = '';
feedbackElement.value = '';
}
function delRow(r) {
// 指定i=r(this)的父層+父層
var i = r.parentNode.parentNode.rowIndex;
// 刪除指定階層
document.getElementById("Feedback_table").deleteRow(i);
alert("謝謝您的回饋，我們已將資訊刪除!");
}
