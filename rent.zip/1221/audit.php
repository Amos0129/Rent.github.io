<?php
    require_once('connectDB.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>房屋審核</title>
    <link rel="stylesheet" type="text/css" href="css/audit.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</head>
<body>
<?php
          session_start();
          if($_SESSION['mylogin']){
              
        }else{
            echo "<script language=javascript>alert('請登入')</script>";
            header("refresh:0;url=login.php");
        }
        ?>
    <?php 
        $query = "SELECT * FROM form";

        $query_run = mysqli_query($link,$query);
    ?>

    <header class="main-header">
        <div class="container">
            <a href="" class="logo">
                <img src="img/logo.png" alt="">
            </a>
            <nav class="main-nav">
                <a href="homepage.php">首頁</a>
                <a href="faq.php">諮詢中心</a>
                <a href="manage.php">租屋管理區</a>
                <?php               
                  if($_SESSION['mylogin'] && $_SESSION['account']){
                    echo "<a href='loginOut.php'>登出</a>";
                  }
                  else{
                    echo "<a href='login.php'>登入</a>";
                  }
                ?>
            </nav>
        </div>
    </header>

    <div class="filter">
        <div class="">    
        <table align="center">
            <tr>
                <th>編號</th>
                <th>地址</th>
                <th>類型</th>
                <th>房數</th>
                <th>租金</th>
                <th>樓層</th>
                <th>設備</th>
                <th>上傳日期</th>
                <th>照片</th>
                <th>聯絡人姓名</th>
                <th>聯絡人電話</th>
                <th>備註</th>
                <th>安全項目</th>
                <th>是否出租</th>
                <th>審核</th>
            </tr>
            <?php
				if(mysqli_num_rows($query_run) > 0)
				{
				    foreach($query_run as $row)
					{
                        $number = $row["編號"];
			?>
						<tr>
                            <td><?php echo $row["編號"];        ?></td>
							<td><?php echo $row["地址"];        ?></td> 
							<td><?php echo $row["類型"];        ?></td> 
							<td><?php echo $row["房數"];        ?></td>
                            <td><?php echo $row["租金"];        ?></td> 
							<td><?php echo $row["樓層"];        ?></td> 
							<td><?php echo $row["設備"];        ?></td>
                            <td><?php echo $row["上傳日期"];    ?></td> 
							<td><?php echo $row["照片"];        ?></td>
                            <td><?php echo $row["聯絡人姓名"];  ?></td>
                            <td><?php echo $row["聯絡人電話"];  ?></td>
							<td><?php echo $row["備註"];        ?></td>
                            <td><?php echo $row["安全項目"];    ?></td> 
                            <td><?php echo $row["是否出租"];    ?></td>
                            <td>
                                <div class="switch">
                                <input class="switch-checkbox" id="<?php echo $number;?>" <?php if($row["審核"] == "通過") echo "checked";?> type="checkbox" onclick="check(<?php echo $number;?>)">
                                <label class="switch-label" for="<?php echo $number;?>">
                                    <span class="switch-txt" turnOn="通過" turnOff="未通過"></span>
                                    <span class="switch-Round-btn"></span>
                                </label>
                                </div>
                            </td> 
						</tr>
			<?php
				    }
				}

                
			?>
        </table>
        </div>
    </div>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.4.1.js"
    integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="crossorigin="anonymous">
</script>
<script>
    function check(checkNumber){
        var checkBoxStatus = $('#' + checkNumber).prop("checked");

        $.ajax({
            type: 'POST',
            url: 'postProcessing.php',
            data: {Number: checkNumber, Status: checkBoxStatus},
        })
    }
</script>