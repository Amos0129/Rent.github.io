<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理區</title>
    <link rel="stylesheet" type="text/css" href="css/manage.css">
</head>
<body>
    <?php
        //判斷是否登入,未登入導回登入頁
        session_start();
        
        if($_SESSION['mylogin']){
              
        }else{
            echo "<script language=javascript>alert('請登入')</script>";
            header("refresh:0;url=login.php");
        }
    ?>
    <header class="main-header">
        <div class="container">
            <a href="" class="logo">
                <img src="img/logo.png" alt="">
            </a>
            <nav class="main-nav">
                <a href="homepage.php">首頁</a>
                <a href="faq.php">諮詢中心</a>
                <a href="manage.php">租屋管理區</a>
                <?php               
                  if($_SESSION['mylogin'] && $_SESSION['account']){
                      echo "<a href='loginOut.php'>登出</a>";
                  }
                  else{
                      echo "<a href='login.php'>登入</a>";
                  }
                ?>
            </nav>
        </div>
    </header>

    <div class="wrap">
        <div class="mid1">
            <div class="upload">
			<br>
                <h1>房屋上傳區</h1>
                    <div class="btn-group">
                        <button class="btn"><a href="upload.php">房屋上傳</a></button>
                    </div>
            </div>
        </div>

        <div class="mid2">
            <div class="audit">
			<br>
                <h1>房屋審核區</h1>
                    <div class="btn-group">
                        <button class="btn"><a href="audit.php">房屋審核</a></button>
                    </div>
            </div>
        </div>
    </div>  
</body>
</html>